# Build-Bench instruction-source cache

This archive preserves every unique nonempty URL referenced by `retrieval_labels.json`: both candidate sources in `build_commands` and selected sources in `ground_truth`.

- Archive creation time (UTC): `2026-08-26T00:44:26+00:00`
- Label rows: 130
- Unique source URLs: 172
- Successfully cached: 172
- Failed: 0

For a bare GitHub repository URL, `content.*` is the root README. When the URL identifies the benchmark repository, the README is extracted from the exact pinned benchmark commit. GitHub blob URLs are also extracted from that commit when possible. Other sources are HTTP response snapshots taken at the archive creation time. Linked assets such as stylesheets, fonts, analytics code, and images are intentionally excluded because they are not build-instruction content.

`manifest.json` maps each original URL and its label roles to the cached file, retrieval method, provenance, SHA-256 digest, byte count, and status. `retrieval_labels.json` is an unchanged copy of the input labels. `repository_commits.csv` records the pinned commits used for local Git extraction. `cache_instruction_sources.py` is the script used to create this archive.

Important limitation: HTTP snapshots created after benchmark construction establish a stable camera-ready release copy, but by themselves cannot prove that an external page had identical content at the time of the original experiments. The pinned-commit Git extractions do reconstruct the corresponding repository content exactly.
