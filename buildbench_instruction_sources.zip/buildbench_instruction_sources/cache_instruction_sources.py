#!/usr/bin/env python3
"""Create a provenance-preserving cache of Build-Bench instruction sources."""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import json
import mimetypes
import re
import shutil
import subprocess
import tempfile
import time
import zipfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlsplit

import requests


USER_AGENT = "BuildBench-instruction-source-archiver/1.0"
README_PATTERN = re.compile(r"^readme(?:\..+)?$", re.IGNORECASE)
README_PREFERENCE = ("README.md", "README.rst", "README.txt", "README")


def run_git(repo: Path, *args: str) -> bytes:
    return subprocess.run(
        ["git", "-C", str(repo), *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).stdout


def normalize_url(value: str) -> str:
    return value.strip()


def github_parts(url: str) -> tuple[str, str, list[str]] | None:
    parsed = urlsplit(url)
    if parsed.netloc.lower() not in {"github.com", "www.github.com"}:
        return None
    parts = [unquote(part) for part in parsed.path.strip("/").split("/") if part]
    if len(parts) < 2:
        return None
    return parts[0], parts[1].removesuffix(".git"), parts[2:]


def github_pages_parts(url: str, repo_slug: str) -> list[str] | None:
    parsed = urlsplit(url)
    owner, repository = repo_slug.split("/", 1)
    if parsed.netloc.lower() != f"{owner.lower()}.github.io":
        return None
    parts = [unquote(part) for part in parsed.path.strip("/").split("/") if part]
    if not parts or parts[0].lower() != repository.lower():
        return None
    return parts[1:]


def media_extension(media_type: str, source_path: str = "") -> str:
    suffix = Path(source_path).suffix
    if suffix and len(suffix) <= 10:
        return suffix
    media_type = media_type.split(";", 1)[0].strip().lower()
    preferred = {
        "text/html": ".html",
        "text/markdown": ".md",
        "text/plain": ".txt",
        "application/json": ".json",
        "application/pdf": ".pdf",
    }
    return preferred.get(media_type) or mimetypes.guess_extension(media_type) or ".bin"


def load_commits(path: Path) -> dict[str, str]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = csv.DictReader(handle)
        return {row["repo_name"].lower(): row["commit_hash"] for row in rows}


def clone_for(repo_slug: str, clones_root: Path) -> Path | None:
    expected = clones_root / repo_slug.split("/", 1)[-1]
    if (expected / ".git").is_dir():
        return expected
    wanted = expected.name.lower()
    matches = [p for p in clones_root.iterdir() if p.is_dir() and p.name.lower() == wanted]
    return matches[0] if len(matches) == 1 and (matches[0] / ".git").is_dir() else None


def root_readme(repo: Path, commit: str) -> str:
    names = run_git(repo, "ls-tree", "--name-only", commit).decode("utf-8").splitlines()
    candidates = [name for name in names if README_PATTERN.fullmatch(Path(name).name)]
    for preferred in README_PREFERENCE:
        for candidate in candidates:
            if candidate == preferred:
                return candidate
    if not candidates:
        raise FileNotFoundError(f"No root README found at {commit}")
    return sorted(candidates, key=str.casefold)[0]


def resolve_blob_path(repo: Path, commit: str, tail: list[str]) -> str:
    if len(tail) < 3 or tail[0] != "blob":
        raise ValueError("Not a GitHub blob URL")
    # A branch or tag can contain slashes. Try every possible split and retain
    # the longest path that exists at the benchmark commit.
    candidates = ["/".join(tail[i:]) for i in range(2, len(tail))]
    existing = []
    for candidate in candidates:
        result = subprocess.run(
            ["git", "-C", str(repo), "cat-file", "-e", f"{commit}:{candidate}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            existing.append(candidate)
    if not existing:
        raise FileNotFoundError("Blob path does not exist at the benchmark commit")
    return max(existing, key=lambda value: value.count("/"))


def cache_from_git(
    url: str,
    repo_slug: str,
    commit: str,
    clone: Path,
) -> tuple[bytes, dict]:
    parsed = github_parts(url)
    if parsed is None:
        raise ValueError("Not a GitHub URL")
    owner, repository, tail = parsed
    target_slug = f"{owner}/{repository}"
    if target_slug.lower() != repo_slug.lower():
        raise ValueError("GitHub URL points to a different repository")
    if not tail:
        source_path = root_readme(clone, commit)
        method = "pinned_git_root_readme"
    elif tail[0] == "blob":
        source_path = resolve_blob_path(clone, commit, tail)
        method = "pinned_git_blob"
    else:
        raise ValueError("GitHub URL is neither a repository root nor a blob")
    content = run_git(clone, "show", f"{commit}:{source_path}")
    media_type = mimetypes.guess_type(source_path)[0] or "text/plain"
    return content, {
        "cache_method": method,
        "git_commit": commit,
        "git_path": source_path,
        "media_type": media_type,
        "resolved_url": f"https://github.com/{target_slug}/blob/{commit}/{source_path}",
    }


def cache_github_pages_from_git(
    url: str,
    repo_slug: str,
    commit: str,
    clone: Path,
) -> tuple[bytes, dict]:
    page_parts = github_pages_parts(url, repo_slug)
    if page_parts is None:
        raise ValueError("Not this repository's GitHub Pages URL")
    page_path = "/".join(page_parts).rstrip("/")
    stems = [page_path]
    if page_path.endswith(".html"):
        stems.append(page_path[:-5])
    candidates = []
    for stem in stems:
        for suffix in ("", ".md", "/index.md"):
            candidate = f"{stem}{suffix}".strip("/")
            if candidate:
                candidates.extend((candidate, f"docs/{candidate}"))
        if not stem:
            candidates.extend(("index.md", "docs/index.md", "README.md"))
    for candidate in dict.fromkeys(candidates):
        result = subprocess.run(
            ["git", "-C", str(clone), "cat-file", "-e", f"{commit}:{candidate}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if result.returncode == 0:
            content = run_git(clone, "show", f"{commit}:{candidate}")
            return content, {
                "cache_method": "pinned_git_github_pages_source",
                "git_commit": commit,
                "git_path": candidate,
                "media_type": mimetypes.guess_type(candidate)[0] or "text/plain",
                "resolved_url": f"https://github.com/{repo_slug}/blob/{commit}/{candidate}",
            }
    raise FileNotFoundError("No matching GitHub Pages source found at the benchmark commit")


def github_readme_from_api(session: requests.Session, owner: str, repo: str) -> tuple[bytes, dict]:
    api_url = f"https://api.github.com/repos/{owner}/{repo}/readme"
    response = session.get(api_url, timeout=45)
    response.raise_for_status()
    payload = response.json()
    content = base64.b64decode(payload["content"])
    source_path = payload["path"]
    return content, {
        "cache_method": "github_api_root_readme",
        "git_commit": None,
        "git_path": source_path,
        "media_type": mimetypes.guess_type(source_path)[0] or "text/plain",
        "resolved_url": payload.get("html_url") or api_url,
        "github_blob_sha": payload.get("sha"),
        "http_status": response.status_code,
        "response_headers": dict(response.headers),
    }


def cache_from_web(session: requests.Session, url: str) -> tuple[bytes, dict]:
    parsed = github_parts(url)
    if parsed is not None and not parsed[2]:
        return github_readme_from_api(session, parsed[0], parsed[1])
    response = session.get(url, timeout=45, allow_redirects=True)
    response.raise_for_status()
    return response.content, {
        "cache_method": "http_snapshot",
        "git_commit": None,
        "git_path": None,
        "media_type": response.headers.get("Content-Type", "application/octet-stream"),
        "resolved_url": response.url,
        "http_status": response.status_code,
        "response_headers": dict(response.headers),
    }


def collect_sources(labels: list[dict]) -> dict[str, dict]:
    sources: dict[str, dict] = defaultdict(
        lambda: {"candidate_for_repos": set(), "ground_truth_for_repos": set()}
    )
    for row in labels:
        repo_name = row["repo_name"].strip()
        for raw_url in row.get("build_commands", []):
            url = normalize_url(raw_url)
            if url:
                sources[url]["candidate_for_repos"].add(repo_name)
        url = normalize_url(row.get("ground_truth", ""))
        if url:
            sources[url]["ground_truth_for_repos"].add(repo_name)
    return sources


def write_readme(path: Path, metadata: dict) -> None:
    path.write_text(
        f"""# Build-Bench instruction-source cache

This archive preserves every unique nonempty URL referenced by `retrieval_labels.json`: both candidate sources in `build_commands` and selected sources in `ground_truth`.

- Archive creation time (UTC): `{metadata['created_at_utc']}`
- Label rows: {metadata['label_row_count']}
- Unique source URLs: {metadata['source_count']}
- Successfully cached: {metadata['success_count']}
- Failed: {metadata['failure_count']}

For a bare GitHub repository URL, `content.*` is the root README. When the URL identifies the benchmark repository, the README is extracted from the exact pinned benchmark commit. GitHub blob URLs are also extracted from that commit when possible. Other sources are HTTP response snapshots taken at the archive creation time. Linked assets such as stylesheets, fonts, analytics code, and images are intentionally excluded because they are not build-instruction content.

`manifest.json` maps each original URL and its label roles to the cached file, retrieval method, provenance, SHA-256 digest, byte count, and status. `retrieval_labels.json` is an unchanged copy of the input labels. `repository_commits.csv` records the pinned commits used for local Git extraction. `cache_instruction_sources.py` is the script used to create this archive.

Important limitation: HTTP snapshots created after benchmark construction establish a stable camera-ready release copy, but by themselves cannot prove that an external page had identical content at the time of the original experiments. The pinned-commit Git extractions do reconstruct the corresponding repository content exactly.
""",
        encoding="utf-8",
    )


def create_zip(source_dir: Path, output_zip: Path) -> None:
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    temp_zip = output_zip.with_suffix(output_zip.suffix + ".tmp")
    with zipfile.ZipFile(temp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source_dir.rglob("*")):
            if path.is_file():
                archive.write(path, Path(source_dir.name) / path.relative_to(source_dir))
    temp_zip.replace(output_zip)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--commits", type=Path, required=True)
    parser.add_argument("--clones-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--delay", type=float, default=0.25)
    args = parser.parse_args()

    with args.labels.open(encoding="utf-8") as handle:
        labels = json.load(handle)
    commits = load_commits(args.commits)
    sources = collect_sources(labels)
    created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml,*/*;q=0.8"})

    with tempfile.TemporaryDirectory(prefix="buildbench-source-cache-") as temp:
        root = Path(temp) / "buildbench_instruction_sources"
        source_root = root / "sources"
        source_root.mkdir(parents=True)
        shutil.copy2(args.labels, root / "retrieval_labels.json")
        shutil.copy2(args.commits, root / "repository_commits.csv")
        shutil.copy2(Path(__file__), root / "cache_instruction_sources.py")

        manifest = []
        for index, (url, roles) in enumerate(sorted(sources.items()), start=1):
            source_id = hashlib.sha256(url.encode("utf-8")).hexdigest()[:16]
            record = {
                "source_id": source_id,
                "original_url": url,
                "candidate_for_repos": sorted(roles["candidate_for_repos"]),
                "ground_truth_for_repos": sorted(roles["ground_truth_for_repos"]),
                "archived_at_utc": created_at,
                "status": "failed",
            }
            relevant_repos = record["ground_truth_for_repos"] or record["candidate_for_repos"]
            content = None
            last_error = None

            for repo_slug in relevant_repos:
                commit = commits.get(repo_slug.lower())
                clone = clone_for(repo_slug, args.clones_root)
                if not commit or not clone or github_pages_parts(url, repo_slug) is None:
                    continue
                try:
                    content, details = cache_github_pages_from_git(url, repo_slug, commit, clone)
                    record.update(details)
                    break
                except (ValueError, FileNotFoundError, subprocess.CalledProcessError) as error:
                    last_error = f"Pinned GitHub Pages extraction: {error}"

            # A URL may occur for multiple labels, but pinned extraction is only
            # unambiguous when it points to the same benchmark repository.
            parsed = github_parts(url)
            if content is None and parsed is not None:
                target_slug = f"{parsed[0]}/{parsed[1]}"
                matching_repos = [repo for repo in relevant_repos if repo.lower() == target_slug.lower()]
                if matching_repos:
                    repo_slug = matching_repos[0]
                    commit = commits.get(repo_slug.lower())
                    clone = clone_for(repo_slug, args.clones_root)
                    if commit and clone:
                        try:
                            content, details = cache_from_git(url, repo_slug, commit, clone)
                            record.update(details)
                        except (ValueError, FileNotFoundError, subprocess.CalledProcessError) as error:
                            last_error = f"Pinned Git extraction: {error}"

            if content is None:
                for attempt in range(1, args.retries + 1):
                    try:
                        content, details = cache_from_web(session, url)
                        record.update(details)
                        break
                    except (requests.RequestException, ValueError, KeyError) as error:
                        last_error = f"Web retrieval attempt {attempt}: {error}"
                        if attempt < args.retries:
                            time.sleep(attempt)

            if content is not None:
                extension = media_extension(record["media_type"], record.get("git_path") or urlsplit(url).path)
                relative_path = Path("sources") / f"{source_id}{extension}"
                (root / relative_path).write_bytes(content)
                record.update(
                    {
                        "status": "ok",
                        "archive_path": relative_path.as_posix(),
                        "sha256": hashlib.sha256(content).hexdigest(),
                        "byte_count": len(content),
                    }
                )
            else:
                record["error"] = last_error or "No retrieval method succeeded"
            manifest.append(record)
            print(f"[{index:03d}/{len(sources)}] {record['status']:6s} {url}", flush=True)
            if args.delay:
                time.sleep(args.delay)

        metadata = {
            "schema_version": 1,
            "created_at_utc": created_at,
            "label_row_count": len(labels),
            "source_count": len(manifest),
            "success_count": sum(row["status"] == "ok" for row in manifest),
            "failure_count": sum(row["status"] != "ok" for row in manifest),
        }
        (root / "manifest.json").write_text(
            json.dumps({"metadata": metadata, "sources": manifest}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        write_readme(root / "README.md", metadata)
        create_zip(root, args.output)

    print(json.dumps(metadata, indent=2))
    print(f"Wrote {args.output}")
    return 0 if metadata["failure_count"] == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
